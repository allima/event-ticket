package com.devtiro.tickets.domain.entities;

public enum TicketValidationStatusEnum {
  VALID, INVALID, EXPIRED
}
