package com.devtiro.tickets.domain.entities;

public enum EventStatusEnum {
  DRAFT, PUBLISHED, CANCELLED, COMPLETED
}
