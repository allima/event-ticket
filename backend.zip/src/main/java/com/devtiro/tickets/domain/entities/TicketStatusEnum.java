package com.devtiro.tickets.domain.entities;

public enum TicketStatusEnum {
  PURCHASED, CANCELLED
}
