package com.devtiro.tickets.domain.entities;

public enum TicketValidationMethod {
  QR_SCAN, MANUAL
}
